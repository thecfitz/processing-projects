import java.util.Scanner;  

/**
 * WordStats prints stats about words.
 * 
 */
public class WordStats
{
    /** main()
     *  
     *  prints stats each time the user enters a new word
     */
    public static void main(String[] args) {
        Scanner sin = new Scanner(System.in);  // Keyboard input
        String[] words = new String[20];
        
        int numWords = 0;
        // while the user enters words...
        while (sin.hasNext()) {
            words[numWords++] = sin.next();
            
            // use a normal for loop to print "Words: word1 word2 ...\n"
            System.out.print("Words: ");
            for (int i = 0; i<numWords; i++) {
                System.out.print(words[i] + " ");
            }
            System.out.println();
            float sum = 0.0f;
            // use a for-each loop to compute the average length of the words (a float)
            for (String i : words) {
                if (i != null) {
                    sum += i.length();
                }
            }
            System.out.println("Number of words:" + numWords + ",average length: " + (sum/numWords));
            // Print "Number of words: n, Average length: a"
        }   
    }
}