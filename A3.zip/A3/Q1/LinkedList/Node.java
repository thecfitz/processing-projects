/**
 * A LinkedList Node.
 * 
 * @author David Gillman
 */
public class Node<T>
{
    // instance variables - replace the example below with your own
    private T data;
    private Node<T> next;

    /**
     * Constructor for objects of class Node
     */
    public Node(T userData, Node<T> userNode)
    {
        this.data = userData;
        this.next = userNode;
    }

    /**
     * Accessor for data
     */
    public T getData()
    {
        return data;
    }

    /**
     * Mutator for data
     */
    public void setData(T newData)
    {
        this.data = newData;
    }

    /**
     * Accessor for next
     */
    public Node<T> getNext()
    {
        return next;
    }

    /**
     * Mutator for next
     */
    public void setNext(Node<T> newNext)
    {
        this.next = newNext;
    }

    public String toString() {
        return this.data.toString();
    }
}
