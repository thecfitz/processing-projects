
/**
 * A LinkedList implementation.
 * 
 * @author David Gillman 
 */
import java.util.ArrayList;
public class LinkedList<T>
{
    public Node<T> front;
    private int size = 0;

    /**
     * Default constructor: make an empty list 
     */
    public LinkedList()
    {
        // front is initially null; the list is empty
    }
     
    /** Methods for Q1
     * 
     */
    
    /** returns True if the list is empty
     * 
     */
    public boolean isEmpty() {
        return (size == 0);
    }
    
    /**
     * Add a piece of data in a new Node at the end of the list
     * 
     * @param  newData   piece of data to add
     */
    public void add(T newData)
    {
        if (front == null) {
            front = new Node<T>(newData, null);
        }
        else {
            Node<T> n = front;
            
            // find the last node ...
            while (n.getNext() != null) {
                n = n.getNext();
            }
            
            // ... and add the new data to a new Node at the end
            Node<T> newNode = new Node<T>(newData, null);
            n.setNext(newNode);
        }
        size += 1;
    }
    
    /** represents the list as a String, for printing
     * 
     */
     public String toString() {
        String comma = ", ";
        String retval = "";
        Node<T> n = front;
        while (n != null) {
            if (n.getNext() == null) {
                comma = "";
            }
            retval += n.getData() + comma;
            n = n.getNext();
        }
        return retval;
    }
    
    /** resets this list to the empty list
     * 
     */
    public void clear() {
        front = null;
    }
  
    /**  returns the index of the first occurrence of e in the list, or -1 if e is not in the list. 
     *   Important: think carefully about what T is, and how you should compare two elements.
     */
    public int contains(T e) {
        Node<T> currentNode = front;  //assigns the front node to currentNode
        T nodeValue = currentNode.getData(); //assigns the node value to nodeValue
        //for loop counts the "index" of the linked list and checks for e
        for (int i = 0; i < this.size(); i ++) {
            if (nodeValue == e) {
                return i;
            }
            //getNext() iterates through the linkedlist and assigns node position to currentNode
            currentNode = currentNode.getNext();
            nodeValue = currentNode.getData();
        }
        return -1;
    }
    
    /** returns the element at the specified index (starting from 0) in the list. 
     *  The method should return null if the index is invalid. 
     *  It should not crash the program if an invalid index is passed.
     * 
     */
    public T get(int index) {
         Node<T> currentNode = front;
         T element = currentNode.getData();
         ArrayList<Node> nodeList = new ArrayList<Node>();
        for (int i = 0; i < this.size(); i ++) {
          nodeList.add(element);
          
           
            
        }
        return null;
    }
    
    /** Methods for Q2
     */    
    
    /** Sets the data at the specified index to e. Has no effect if index < 0 or index >= this.size().
     * 
     */
    void set(int index, T e) {
        if (index >= 0 && index < this.size()) {
            Node<T> n = front;
            int currentIndex = 0;
            while (currentIndex < index) {
                n = n.getNext();
            }
            n.setData(e);
        }
    }
    
    /**
     * Adds data to the front of the list
     * 
     * @param: data to add  
     */
    public void addFirst(T e) 
    {
        Node<T> n = new Node<T>(e, front);
        front = n;
    }
    
    /** returns the number of elements in the list - slow version
     * 
     */
    public int slowSize() {
        Node<T> n = front;
        size = 0;
        while (n != null) {
            size += 1;
            n = n.getNext();
        }
        return size;
    }
    
    /** returns the number of elements in the list - fast version
     * 
     */
    public int size() {
        return size;
    }
    
    /** Removes the Node at the front of the list
     * 
     * @returns: nothing  
     */
    public void removeFirst()  
    {
        if (front != null) { // otherwise nothing to remove
            
            // move the second Node to the front
            front = front.getNext();
            size -= 1;
        } 
    }
    
    /** Removes the last element of the list. Has no effect on an empty list.
     * 
     * Make sure that:
     * - the Node containing the last element is removed
     * - the second-to-last Node now points to null
     * 
     * @returns: nothing  
     */
    public void removeLast()  
    {
    }
    
    /** Removes the element at the specified index. Has no effect if that index does not exist.
     * 
     * Make sure that:
     * - the Node containing the middle element is removed
     * - the Node before now points to the node after
     * 
     * @param: index of element to be removed
     * @returns: nothing  
     */
    public void removeMiddle(int index)  
    {
    }
}
