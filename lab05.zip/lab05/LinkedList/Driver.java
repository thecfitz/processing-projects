import java.lang.System;
import java.util.Scanner;
import java.util.LinkedList; //uncomment to use Java's LinkedList

/**
 * Write a description of class Driver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Driver
{
    public static void main(String[] argv) {
        LinkedList<Integer> myList = new LinkedList<Integer>();
        Scanner sysin = new Scanner(System.in);
        int n = 0;
        
        // For each user input n, measure the time it takes to make a list of n integers and print the time in milliseconds. 
        while(sysin.hasNextInt()) {
            n = sysin.nextInt();
            long startTimeNS = System.nanoTime();
            for (int i = 0; i < n; i++) {
                myList.add(i);
            }
            float elapsedTimeMS = 0.0f; //stubbed: compute elapsed time in nanoseconds and convert to milliseconds
            long endTime = System.nanoTime();
            System.out.println("Elapsed time: " + (endTime - startTimeNS)/1000000.0);
            myList.clear();
        }
        
        
    }
}