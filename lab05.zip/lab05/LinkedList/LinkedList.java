/**
 * A LinkedList implementation.
 * 
 * @author David Gillman 
 */
public class LinkedList<T>
{
    public Node<T> front;
    private int size;
    private Node<T> back;

    /**
     * Default constructor: make an empty list 
     */
    public LinkedList()
    {
        front = null;
        size = 0;
    }

    /**
     * Clear: remove all references to nodes
     */
    void clear() {
        front = null;
        size = 0;
    }
    
    /**
     * Add a piece of data in a new Node at the end of the list
     * 
     * @param  newData   piece of data to add
     */
    public void add(T newData)
    {
        if (front == null) {
            front = new Node<T>(newData, null);
            this.back = this.front;
        }
        else {
            this.back.setNext(new Node<T>(newData, null));
            this.back = this.back.getNext();
        }
        size += 1;
    }

    /**
     * Remove the data and Node at the front of the list
     * 
     * @return  the removed node
     */

    public Node<T> removeFront() // #signature# or #prototype#
    {
        if (front == null) {
            // nothing to remove - just return a null reference
            return null;
        }
        else {
            // create a new reference to the front Node
            Node<T> n = front;
            
            // move the second Node to the front
            front = front.getNext();
            
            // return a reference to the removed Node
            size -= 1;
            return n;
        } 
    }
    public String toString() {
        String spaces = "  ";
        String arrow = "-> ";
        String retval = "";
        Node<T> n = front;
        while (n != null) {
            retval += n.getData() + "\n" + spaces + arrow;
            n = n.getNext();
        }
        return retval;
    }
   
    public int size() {
        return size;
    }
}
