
/**
 * Write a description of class MPGChecker here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */


public class MPGChecker
{
    // instance variables - replace the example below with your own
    int[] g;
    float f;
    float m;
    

    /**
     * Constructor for objects of class MPGChecker
     */
    public MPGChecker(int[] gasStations, float fuelTank, float MPG)
    {
        // initialise instance variables
        this.g = gasStations;
        this.f = fuelTank;
        this.m = MPG;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public boolean safe()
    {
        // put your code here
        for (int i : g) {
            if (f * m < i) {
                return false;
            }
          
        }
        return true;
    }
}
