import java.util.LinkedList;

public class JavaLinkedListDriver
{
    public static void main(String[] argv) {
        // fill a LinkedList with the first 1000 odd numbers
        LinkedList<Integer> oddNums = new LinkedList<Integer>();
        int i;
        for (i = 1; i <= 100000; i++) {
            oddNums.add(new Integer(2*i-1));
        }
        
        // Let the nth item in sums contain the sum of the first n items in odds.
        LinkedList<Integer> sums = new LinkedList<Integer>();
        Integer sum = 0;
        sums.add(sum); // the 0th sum
        for (Integer odd: oddNums) { // #foreach# syntax: odd is the dummy variable
            //#0 add the next odd number to the sum
            
            //#1 add the new sum to sums
            
        }
        
        // print the 1st, 2nd, 3rd, 4th, 10th, 100th, 1000th, 10000th, and 100000th items in sums
        int[] itemsToPrint = {1, 2, 3, 4, 10, 100, 1000, 10000, 100000};
        //#2 for each item in itemsToPrint: 
            //#3 print "The ___th sum is ____" 
    }
}
