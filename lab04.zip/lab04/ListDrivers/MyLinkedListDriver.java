import java.util.Scanner;

/**
 * LinkedList and Node Driver
 * 
 * @author David Gillman 
 */
public class MyLinkedListDriver
{
    /* main - add elements then remove elements from the front; print the list each time
     * 
     */
    public static void main(String[] argv)
    {
        Scanner sysin = new Scanner(System.in);
        MyLinkedList<Integer> list = new MyLinkedList<Integer>();
        /*#0 Declare a Node<Integer> reference variable n and set it to null.  
         */ 
        Node <Integer> n = null;
        // add elements to the end
        while (sysin.hasNextInt()) {
            
            /*#1 Google "Java Scanner" and find the method for reading the next integer from an input stream.
             *   Read the next integer from System.in and add it to the end of the MyLinkedList.
             */
            list.add(sysin.nextInt());
            System.out.println(list);
        }
        
        /*#2 Print the length of the list
         */
        System.out.print(list.size());
        // remove elements from the front
        n = list.removeFront();
        while (n != null) {
            System.out.println("Removed: " + n.getData());           
            
            /*#3 Remove the first item from the list. Assign a reference to the item to n.
             */
            System.out.print(list);
            n = list.removeFront();
            /*#4 Print the remaining list
             */
            
        }
    }
    
}
